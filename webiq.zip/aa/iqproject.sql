-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2019 at 03:19 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iqproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` int(10) NOT NULL,
  `message` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `contact`, `message`, `created_at`, `updated_at`) VALUES
(1, '', '', 0, '', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(2, 'Ashu', 'goyalashu2282@gmail.com', 2147483647, 'fc bv nb mn m', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(3, 'ssxsss', 'goyal@gmail.com', 789456123, 'xgvjnbkn', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(4, 'sxsxsss', 'goyal@gmail.com', 789456123, 'xgvjnbkn', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(5, 'aadas', 'das@dsfd.sdf', 21312, 'asd', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(6, 'asd', 'anil.websetters@gmail.com', 123123123, 'asd', '2019-07-01 06:39:26', '2019-07-01 01:09:26'),
(7, 'triptoplan', 'editor@gmail.com', 0, 'sdfasdf', '2019-07-01 06:42:47', '2019-07-01 01:12:47'),
(8, 'triptoplan', 'editor@gmail.com', 0, 'sdfasdf', '2019-07-01 06:43:51', '2019-07-01 01:13:51'),
(9, 'triptoplan', 'editor@gmail.com', 0, 'sdfasdf', '2019-07-01 06:44:09', '2019-07-01 01:14:09'),
(10, 'triptoplan', 'editor@gmail.com', 0, 'sdfasdf', '2019-07-01 06:44:59', '2019-07-01 01:14:59');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `emai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`emai`) VALUES
('goyalashu2282@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `school` varchar(50) NOT NULL,
  `photo` longblob NOT NULL,
  `aadharcard` longblob NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `password`, `email`, `dob`, `phone`, `address`, `state`, `qualification`, `school`, `photo`, `aadharcard`, `created_at`, `updated_at`) VALUES
(1, 'triptoplan', '', 'anil.websetters@gmail.com', '2019-06-15', 3423434, '#1198 SECTOR 56', 'Chandigarh', '4-6', 'Delhi Public School Chandigarh', '', '', '2019-07-01 06:24:48', '2019-07-01 00:54:48'),
(2, 'triptoplan', 'pYNr8AXgmPqz', 'anil.websetters@gmail.com', '2019-06-15', 3423434, '#1198 SECTOR 56', 'Chandigarh', '4-6', 'Delhi Public School Chandigarh', '', '', '2019-07-01 06:34:16', '2019-07-01 01:04:16'),
(3, 'triptoplan', 'AUN%&yuXT@wB', 'anil.websetters@gmail.com', '2019-06-15', 3423434, '#1198 SECTOR 56', 'Chandigarh', '4-6', 'Delhi Public School Chandigarh', '', '', '2019-07-01 06:35:16', '2019-07-01 01:05:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
