<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="author" content="" />
<meta name="robots" content="" />
<meta name="description" content="" />
<meta name="format-detection" content="telephone=no">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<style>

.modal.left .modal-dialo,
.modal.right .modal-dialo 
{
    
         position: fixed;
        margin: auto;
        width: 700px;
        height: 100%;
        -webkit-transform: translate3d(0%, 0, 0);
            -ms-transform: translate3d(0%, 0, 0);
             -o-transform: translate3d(0%, 0, 0);
                transform: translate3d(0%, 0, 0);
}
@media (max-width:400px){
     .modal.left .modal-dialo,
.modal.right .modal-dialo {
        width: 100%;
    }
}

.modal.left .modal-conten,
.modal.right .modal-conten 
{
        height:100%;
        overflow-y: auto;
}
.modal.left .modal-bod,
.modal.right .modal-bod 
     {
        padding: 15px 15px 80px;
     }

.modal.left.fade .modal-dialo
{
        left: -220px;
        -webkit-transition: opacity 0.3s linear, left 0.3s ease-out;
           -moz-transition: opacity 0.3s linear, left 0.3s ease-out;
             -o-transition: opacity 0.3s linear, left 0.3s ease-out;
                transition: opacity 0.3s linear, left 0.3s ease-out;
}
.modal.left.fade.in .modal-dialo
{
 left: 0;}
        
/*Right*/
    .modal.right.fade .modal-dialo {
        right: -320px;
        -webkit-transition: opacity 0.3s linear, right 0.3s ease-out;
           -moz-transition: opacity 0.3s linear, right 0.3s ease-out;
             -o-transition: opacity 0.3s linear, right 0.3s ease-out;
                transition: opacity 0.3s linear, right 0.3s ease-out;
    }
    
    .modal.right.fade.in .modal-dialo {
        right: 0;
    }

/* ----- MODAL STYLE ----- */
    .modal-conten {
        border-radius: 0;
        border: none;
        background-color: white;
        font-size: 16px;
color: black;
    }
.modal-title
{
    color: white;
}
    .modal-head
{background-color: #c11b71;
 padding: 15px 32px;
  text-align: center;
font-size: 16px;
  margin: 4px 2px;
border: none;
  color: white;

}

.demo {
    padding-top: 60px;
    padding-bottom: 110px;
}

.btn-demo {
    margin: 15px;
    padding: 10px 15px;
    border-radius: 0;
    font-size: 16px;
    background-color: #FFFFFF;
}

.btn-demo:focus {
    outline: 0;
}
.button1 {
background-color: #c11b71;
padding: 15px 32px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
border: none;
color: white;
} 
</style>
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<link href="assets/css/login-register.css" rel="stylesheet" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.js" type="text/javascript"></script>
    <script src="assets/js/login-register.js" type="text/javascript"></script>
<!-- Favicons Icon -->

<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
<!-- Page Title Here -->
<title>IQ : Intelligence Quotient - 2019</title>
<!-- Mobile Specific -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--[if lt IE 9]>
        <script src="https://s3.ap-south-1.amazonaws.com/tm-html/educare/educare_html/xhtml/js/html5shiv.min.js"></script>
        <script src="https://s3.ap-south-1.amazonaws.com/tm-html/educare/educare_html/xhtml/js/respond.min.js"></script>
    <![endif]-->
<!-- Stylesheets -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/animate.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/css-slide.css">
<link rel="stylesheet" type="text/css" href="css/style2.css">
<link rel="stylesheet" type="text/css" href="css/scrollbar.css">
<link class="skin"  rel="stylesheet" type="text/css" href="css/skin-2.css">
<link  rel="stylesheet" type="text/css" href="css/coming-soon.css">
<link rel="stylesheet" type="text/css" href="css/switcher.css"/>
<link rel="stylesheet" type="text/css" href="css/sidenav.css"/>
<!-- Google fonts -->
<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Dancing+Script:400,700" rel="stylesheet">
</head>
<body id="bg">
<?php 
require_once 'config.php';
		// initalize user class
		$user_obj = new Cl_User();
		
if(!empty($_REQUEST['contactUs'])){
	try {
		   $data = $user_obj->ContactDetail($_POST);
		} catch (Exception $e) {
				$error = $e->getMessage();
			}
}

?>

<div class="page-wraper">
    
        <div id="loading-area"></div>
    <!-- Content -->
    <div class="blog-page-content style-1 sticky-header  ">
        <!-- Side Nav -->


<div id="mySidenav" class="sidenav coming-side-bar content ">
        <a href="javascript:void(0)" class="closebtn bg-primary" >&times;</a>
            <div class="clearfix"></div>
            <div class="p-b100 p-a30 p-t15">
                <h2>About Us</h2>
                <div class="rdx-separator bg-primary "></div>
                <p style="color:black;">An intelligence quotient (IQ) is a total score derived from several standardized tests designed to assess human intelligence. The abbreviation "IQ" was coined by the psychologist William Stern for the German term Intelligenzquotient, his term for a scoring method for intelligence tests at University of Breslau he advocated in a book.Historically, IQ is a score obtained by dividing a person's mental age score, obtained by administering an intelligence test, by the person's chronological age, both expressed in terms of years and months. The resulting fraction is multiplied by 100 to obtain the IQ score.</p>
                <div class="row">
                    <div class="col-md-4 col-sm-4 m-b30">
                        <div class="icon-bx-wraper bx-style-1 p-a30 center col">
                            <div class="icon-bx-sm text-primary radius border-2 m-b20"> <a href="#" class="icon-cell"><i class="fa fa-building-o"></i></a> </div>
                            <div class="icon-content">
                                <h5 class="rdx-tilte text-uppercase" style="color:black;">School performance</h5>
                                <p style="color:black;">It has been found that the correlation of IQ scores with school performance depends on the IQ measurement used. </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 m-b30">
                        <div class="icon-bx-wraper bx-style-1 p-a30 center col">
                            <div class="icon-bx-sm text-primary  radius border-2 m-b20"> <a href="#" class="icon-cell"><i class="fa fa-user"></i></a> </div>
                            <div class="icon-content">
                                <h5 class="rdx-tilte text-uppercase" style="color:black;">Job performance</h5>
                                <p style="color:black;">According to Schmidt and Hunter, "for hiring employees without previous experience in the job the most valid predictor of future performance is general mental ability."</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 m-b30">
                        <div class="icon-bx-wraper bx-style-1 p-a30 center col">
                            <div class="icon-bx-sm text-primary  radius border-2 m-b20"> <a href="#" class="icon-cell"><i class="fa fa-truck"></i></a> </div>
                            <div class="icon-content">
                                <h5 class="rdx-tilte text-uppercase" style="color:black;">Health and mortality</h5>
                                <p style="color:black;">Multiple studies conducted in Scotland have found that higher IQs in early life are associated with lower mortality and morbidity rates later in life.</p>
                            </div>
                        </div>
                    </div>
                
                </div>
              
            </div>
</div>

        <!-- Full Blog Page Contant -->
<div class="rdx-coming-soon bg-img-fix rdx-coming-soon-full  cs-style-1 p-b100 overlay-black-middle bg-img-fix">
            <ul class="cb-slideshow">
               <li><span style="background-image: url(http://iq19-24.com/images/bg/bg2.jpg) "></span></li>
                <li><span style="background-image: url(http://iq19-24.com/images/bg/bg3.jpg) "></span></li>
                <li><span style="background-image: url(http://iq19-24.com/images/bg/bg1.jpg) "></span></li>
                <li><span style="background-image: url(http://iq19-24.com/images/bg/bg2.jpg) "></span></li>
                <li><span style="background-image: url(http://iq19-24.com/images/bg/bg3.jpg) "></span></li>
                <li><span style="background-image: url(http://iq19-24.com/images/bg/bg1.jpg) "></span></li>
            </ul>
            <div class="container relative z-index2">
                 <div class="rdx-coming-bx text-center f-ele-m" rdx-top-pos="0">
                    <div class="top-head text-center logo-header">
                        <a href="index.php">
                            <img src="images/logo3.png" alt="" />
                        </a>
                    </div>  
                     
                    <div class="coming-soon-content text-center text-white m-b30">
                    
                        <p style="font-size:40px;"><a href="enroll.php"> <h2 id="text"><h3>Enroll yourself for national level quiz competition IQ-2019 </h3></a> </br>
                       
                    </div>
                    <div class="countdown text-center">
                        <div class="date">
                            <span class="days text-primary time"></span>
                            <span class="time-name">Days</span>
                        </div>
                        <div class="date">
                            <span class="hours text-primary time"></span>
                            <span class="time-name">Hours</span>
                        </div>
                        <div class="date">
                            <span class="mins text-primary time"></span>
                            <span class="time-name">Minutes</span>
                        </div>
                        <div class="date">
                            <span class="secs text-primary time"></span>
                            <span class="time-name">Seconds</span>
                        </div>
                    </div>

                   <div class="text-center m-t50 info-style-4">
                        <form role="search" method="post" class="m-t50 m-b30" action="newsletter.php">
                            <div class="input-group max-w400 m-auto">
                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>   
                                <input name="emai" class="form-control radius-xl" placeholder="Enter Your Email" type="text" title="Please Fill Your Email Here" required>
                                <span class="input-group-btn p-l10">
                                    <button  type="submit" name="email" class="site-button radius-xl"><i class="fa fa-send"></i><span>Subscribe</span></button>
                                </span> 
                            </div>
                        </form>
                        <div class="m-b30">
                            <ul class="rdx-social-icon border">
                                <li><a class="fa fa-facebook" href="javascript:void(0);" target="bank"></a></li>
                                <li><a class="fa fa-twitter" href="javascript:void(0);" target="bank"></a></li>
                                <li><a class="fa fa-linkedin" href="javascript:void(0);" target="bank"></a></li>
                                <li><a class="fa fa-google-plus" href="javascript:void(0);" target="bank"></a></li>
                            </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">						
							<a class="site-button m-b30 radius-xl m-lr5 openbtn" id="mySidenav">About Us </a>
							<a class="site-button m-b30 radius-xl m-lr5" data-toggle="modal" data-target="#myModal">Rewards</a>
							<a class="site-button m-b30 radius-xl m-lr5" data-toggle="modal" data-target="#myModal2">Career</a>
							<a class="site-button m-b30 radius-xl m-lr5" data-toggle="modal" href="#" data-target="#Modal">Sponsors</a>
							<a class="site-button m-b30 radius-xl m-lr5" data-toggle="modal" href="#" data-target="#myModal1">Contact Us</a>
						  </div>
						</div>
						<h3 style="color:#fff;font-size: 14px;">Powered by<a href="https://rapstechnologies.com/" target="_blank"><img src="images/logo.png"> </a></h3>
                    
                </div>

               
            </div>
        </div>
</div>
        <!-- Full Blog Page Contant -->
</div>
    <!-- Content END-->
</div>
</div>

<!-- Modal -->
<div class="modal fade contact-form" id="myModal1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="dzFormMsg"></div>
                <form method="post" class="dzForm" action="">
                    <input type="hidden" value="Contact" name="dzToDo" />
                    <div class="clearfix">
                        <div class="col-md-12 p-a0">
                            <div class="form-group">
                                <div class="input-group"> <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <input  placeholder="Your Name" type="text" name="name" class="form-control" required >
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 p-a0">
                            <div class="form-group">
                                <div class="input-group"> <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                    <input  placeholder="Your Email" type="email" name="email" class="form-control" 
                                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required >
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 p-a0">
                            <div class="form-group">
                                <div class="input-group"> <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                    <input  placeholder="Your Mobile No." type="tel" 
                                    maxlength="10" name="subject" pattern="[0-9]+" class="form-control" autocorrect="off" required >
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 p-a0">
                            <div class="form-group">
                                <div class="input-group"> <span class="input-group-addon v-align-t"><i class="fa fa-pencil"></i></span>
                                    <textarea  placeholder="Message" rows="4" name="message" class="form-control" required ></textarea>
                                </div>
                            </div>
                        </div>
                            
                        <div class="col-md-12 p-a0">
                            <button type="submit" value="Submit"  name="contactUs" class="site-button "> <span>Submit</span> </button>
                            <button  type="reset" value="Reset"  class="site-button pull-right gray m-l15"> <span>Reset</span> </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      </div>
      <div class="modal-body">
        <img src="images/sponsors.png" id="imagepreview" style="width: 550px; height: 404px;" >

      </div>
    
    </div>
</div>
<div class="modal left fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialo" role="document">
            <div class="modal-conten">
            
                <div class="modal-head">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Rewards</h4>
                    
                </div>

                <div class="modal-bod">
                                   
                            <div class="table-responsive">
                                <table class="table table-bordered" >
                                <thead>
                                <tr>
                                <th>Price Amount </th>
                                <th>No. Of Winners / Level</th>
                                <th> IQ Test Cost </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                <td>1 Lakh</td>
                                <td>(1 Candidate - National Level)</td>
                                <td>1000/-</td>
                                </tr>
                                <tr>
                                <td>50 K</td>
                                <td>(5 Candidates - Zone Level)</td>
                                <td>500/-</td>
                                </tr>
                                <tr>
                                <td>25 K</td>
                                <td>(36 - Candidates - State / UT Level)</td>
                                <td>250/-</td>
                                </tr>
                                <tr>
                                <td>10 K</td>
                                <td> (50 Candidates )</td>
                                <td>100/-</td>
                                </tr>
                                <tr>
                                <td>100 INR</td>
                                <td> (100 Candidates )</td>
                                <td>10/-</td>
                                </tr>
                                <tr>
                                <td>Consultation Certifications Only</td>
                                <td>300 Candidates</td>
                                <td>1/-</td>
                                </tr>
                                </tbody>
                                </table>
                            </div>
                            <h2 style="color:black;">For Meritorious Candidates only </h2>
                            <h2 style="color:black;">Eligibility: 8th, 9th, 10th, 12th (All State and Centre Board Candidates)</h2>
                            <h2 style="color:black;">*Free Career Counseling Sessions for all registered candidates throughout India</h2>
                               
                                                 
                                                </div>

                                            </div><!-- modal-conten -->
                                        </div><!-- modal-dialo -->
</div><!-- modal -->
                                    
                                    <!-- Modal -->
                <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialo" role="document">
                <div class="modal-conten">
                <div class="modal-head">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel2">Career Counselling</h4>
                </div>

 <div class="modal-bod">
  <div class="container-fluid bg-1 text-center">
 <div class="container-fluid bg-2 text-center">
 <h2>What is the procedure to join NDA after 10th?</h2>
 <p>NDA refers to National Defense Academy and to join NDA you need to qualify NDA entrance examination held by UPSC two times every year.</p>
 <p>* The minimum eligibility criteria required for appearing in NDA entrance examination are as following :-</p>
 <p>i) You must be an unmarried Indian male citizen.</p>
 <p>ii) Your age must lie in between 16.5 years to 19.5 years.</p>
 <p>iii) You must have completed your Class 12th in any discipline from a recognized board of education. Further in order to join Indian Navy or Indian Air force you need to have studied Physics and Mathematics at your Class 12th level. Students pursuing final year are also eligible.</p>
 <p>iv) You must hold the physical fitness as per the service requirement.</p>
 <p>So being a Class 10th pass candidate you need to first complete your Class 12th and then have to qualify NDA entrance examination.</p>
 <p>For more details and updates regarding NDA entrance examination you can visit the link www.upsc.gov.in.</p>
 <h2  class="i">How to join Indian Army after 10th standard</span></h2> <p><br />In this article, we will check out how 10th standard passed students may join the Indian Army. A job in the Indian Army is something that youngsters from India dream about. But many of them don&rsquo;t have exact knowledge about the selection process, eligibility criteria, types of entrance exams etc. In this article, I&rsquo;ll clear all those doubts and show you how you may make it to the Army after clearing 10th standard examination.<br />If you have cleared 10th and are looking to land the post of a Commissioned Officer in the Indian Army, just matriculation won&rsquo;t be sufficient. You&rsquo;ll have to at least have 10+2 schooling under your belt! This entry is called the NDA (National Defence Academy) entry mode.</p>
 <p><h2>Join Indian Air Force after 10+2</h2><br />If you want to be an early bird and wish to Join Indian Air Force right after finishing school, then you need to appear for the NDA examination conducted by UPSC. The required education qualification for NDA entry scheme is 10+2 with Physics and Mathematics and candidate should be between 16 &amp;frac12; to 19 &amp;frac12; years of age. <br />Join Indian Air Force after Graduation<br />Have you missed out on the chance to Join Indian Air Force after 10+2, you have plenty of opportunities to join IAF after graduation. UPSC conducts CDSE and NCC Special entry scheme examination for the Graduate aspirants, for detailed information see below.<br />&bull; CDS Examination<br />CDS examination is conducted for recruitment of trainee pilots in the flying branch, only male graduates are eligible to apply. As mentioned earlier, CDSE exam is conducted by UPSC twice every year. The short listed candidates are trained at the specialised flying training establishment.<br />&bull; NCC Special Entry<br />Aspirants aiming to join the Flying Branch of the Indian Air Force and possessing the Air Wing Senior Division &rsquo;C&rsquo; Certificate of the National Cadet Corps are eligible to apply for NCC Special Entry.<br />Join Indian Air Force after Engineering<br />If you are an engineering graduate aspiring to join the Indian Air force, you have the option to join IAF Technical branch, which is engaged in the maintenance and upkeep of those state of the art machinery. Aspirants can join the IAF after completing their Degree in Engineering or equivalent qualification recognised by the UPSC through the below-mentioned entry schemes.<br />&bull; UES Entry<br />University Entry Scheme (UES) is conducted for pre final year engineering students, for the induction into the technical branch of IAF. The initial training of candidates is conducted at the AFA, and later they are required to join Air Force Technical College in Bangalore for further enhancement of their technical knowledge.</p>
 <p><br /><h2> How to join Indian Army after 10th standard</h2><br />In this article, we will check out how 10th standard passed students may join the Indian Army. A job in the Indian Army is something that youngsters from India dream about. But many of them don&rsquo;t have exact knowledge about the selection process, eligibility criteria, types of entrance exams etc. In this article, I&rsquo;ll clear all those doubts and show you how you may make it to the Army after clearing 10th standard examination.<br />If you have cleared 10th and are looking to land the post of a Commissioned Officer in the Indian Army, just matriculation won&rsquo;t be sufficient. You&rsquo;ll have to at least have 10+2 schooling under your belt! This entry is called the NDA (National Defence Academy) entry mode.</p>
  <p>Join Indian Air Force after 10+2<br />If you want to be an early bird and wish to Join Indian Air Force right after finishing school, then you need to appear for the NDA examination conducted by UPSC. The required education qualification for NDA entry scheme is 10+2 with Physics and Mathematics and candidate should be between 16 &amp;frac12; to 19 &amp;frac12; years of age. <br />Join Indian Air Force after Graduation<br />Have you missed out on the chance to Join Indian Air Force after 10+2, you have plenty of opportunities to join IAF after graduation. UPSC conducts CDSE and NCC Special entry scheme examination for the Graduate aspirants, for detailed information see below.<br />&bull; CDS Examination<br />CDS examination is conducted for recruitment of trainee pilots in the flying branch, only male graduates are eligible to apply. As mentioned earlier, CDSE exam is conducted by UPSC twice every year. The short listed candidates are trained at the specialised flying training establishment.<br />&bull; NCC Special Entry<br />Aspirants aiming to join the Flying Branch of the Indian Air Force and possessing the Air Wing Senior Division &rsquo;C&rsquo; Certificate of the National Cadet Corps are eligible to apply for NCC Special Entry.<br />Join Indian Air Force after Engineering<br />If you are an engineering graduate aspiring to join the Indian Air force, you have the option to join IAF Technical branch, which is engaged in the maintenance and upkeep of those state of the art machinery. Aspirants can join the IAF after completing their Degree in Engineering or equivalent qualification recognised by the UPSC through the below-mentioned entry schemes.<br />&bull; UES Entry<br />University Entry Scheme (UES) is conducted for pre final year engineering students, for the induction into the technical branch of IAF. The initial training of candidates is conducted at the AFA, and later they are required to join Air Force Technical College in Bangalore for further enhancement of their technical knowledge.<br />&bull; AFCAT Entry<br />AFCAT is the largest equipment exercise conducted by the Indian Air Force, and AFCAT is held for the recruitment of Officers (Male/female) for all the three branches of IAF, i.e. Flying, Technical, and Ground Duty. It especially includes the EKT (Engineering Knowledge Test) for Technical branch aspirants.<br />Join Indian Air Force after Post Graduation<br />Apart from the active flying branch, you can also serve in the Indian Air Force in Ground Duty Branches, which comprises of Administration Branch, Accounts Branch, Logistics Branch, Education Branch, and Meteorological Branch.<br />Candidates who have completed their Graduation with Mathematics and Physics and PG in Science stream / Mathematics / Statistics / Geography / Computer Applications / Environmental Science / Applied Physics / Oceanography / Agricultural Meteorology / Ecology &amp; Environment / Geo-physics / Environmental Biology. All candidates should have scored a minimum 50% marks are eligible for the AFCAT for Ground Duty Branches of IAF. Candidates applying for the Ground Duty Branches can join Indian Air Force on Permanent or short service commission basis.<br />Apart from the education qualification, candidates should possess the minimum required physical stature for the post, as notified by the authority.</p>
 <p><br /><h2>BAMS (Bachelor of Ayurvedic Medicine and Surgery)</h2><br />Course Duration: 5&frac12; Years<br />Course Type: Undergraduate Course<br />Eligibility Criteria: 10+2 passed with PCB subjects<br />Qualification Awarded: Bachelor&rsquo;s Degree<br />In this article, we will analyze the professional course called BAMS. BAMS stands for Bachelor of Ayurvedic Medicine and Surgery. This is a professional course that 12th Science students belonging to Biology group (Physics, Chemistry and Biology subjects) may pursue. We will check out basic details of the course, syllabus &amp; important subjects, its value in the job market and career prospects.<br />First of all, let us check out the basic details associated with the course. We will check out what Ayurveda is all about.<br /><br /><h2>BAMS: BASIC DETAILS</h2><br />Ayurveda is a branch of alternative medicine. The term &lsquo;Ayurveda&rsquo; stands for Science of life! It is a mode of treatment that is inspired by natural cure for ailments.<br />This science actually originated in India. Its roots can be traced back to the Vedas! BAMS course is designed to train students get familiar with concepts of Ayurveda and make use of them to treat patients.<br /><br />Ayurveda mostly focuses on natural cures as well as lifestyle changes to cure ailments. The course covers those topics in detail and helps train students to use those very solutions to solve modern day diseases also!<br /><br />In the first year, non-clinical subjects are taught. In second year, subjects like Pharmacology, Pharmacy, Charaka and Toxicology are taught. Some important subjects taught during third year are- Pathology, Obstetrics, Gynaecology and Pediatrics. Some important subjects taught during last one and a half year are- Ayurvedic Surgery, Panchkarma and General Medicine. The last year is dedicated towards Internship.<br /><br />COURSE DURATION<br />BAMS is a five and a half years long course. The last one year is dedicated towards Internship.<br /><br />BAMS SYLLABUS AND IMPORTANT SUBJECTS<br />Sanskrit<br />Ashtang Hridayam<br />Padartha Vigyan<br />Kriyasharir<br />Rachanasharir<br />Ayurveda Ithihas<br />Charaksamhita<br />Dravyaguna Vigyan<br />Rasa Shastra<br />Roga Vigyan<br />Vyavhar Ayurved<br />Kayachikitsa<br />Shalya<br />Shalakya<br />Stri Roga<br />Prasuti Tantra<br />Panchkarma<br /><br />The above mentioned subjects form an Integral part of BAMS program. Note that not all subjects have been mentioned in the above list.<br /><br />ELIGIBILITY CRITERIA<br />Only 12th Science stream, Biology group students are eligible to apply for this course. In most cases, the minimum marks criteria for admission is 50% marks in the 12th Board examinations.<br /><br />ADVANTAGES OF PURSUING BAMS<br />First of all, getting admission in a BAMS college is relatively easier, when compared to other medicine course like MBBS! When it comes to MBBS seats, the competition is cut throat and there are limited number of Government College seats available.<br /><br />In case of BAMS, the competition is not too high. So, even above average students may get admission in a Government College and thus pursue this medicine course without having to spend much money! Sure, BAMS is not as valuable as MBBS. But please read the next paragraph to get a glimpse of the changing trend!</p>
 <p><h2>Career in MBBS:</h2><br />Medical Line is quite tough as compared to Engineering Field. A Medical Degree has been never easy. MBBS (Bachelor of Medicine and Bachelor of Surgery) is the most popular and designated degree of doctors. These are the two bachelor degrees in one domain as the Bachelor of Medicine and the Bachelor of Surgery. This is the tradition of United Kingdom and many universities in various countries are following this tradition.<br />While in the US, both of the degrees are awarded separately as the M.D (Doctor of Medicine)and D.O (Doctor of Osteopathic Medicine). It is the only bachelor degree that makes the students eligible to carry the term &ldquo;doctor&rdquo; with their name.<br />The MBBS is an undergraduate degree programme in medical field. It takes the duration of 5.5 years for the completion of the degree. It is very tough to pursue the MBBS course. This course is now in heavy demand by the students after 12th.<br />Through this course, the students are taught all about the human anatomy, human cytology, medicine, chemistry, pharmaceutical, chemistry, drugs formulation &amp; effect and method of surgery.<br />The Medical Council of India is the only accredited body of medical courses.<br />Course &amp; Duration<br />The MBBS is a 5.5 year (4.5 years academic education + 1 year mandatory internship) UG degree programme leading to the two degrees as Bachelor of Medicine and Bachelor of Surgery.<br />The MBBS is one of the most sought courses after 12th science in medical field. There are so many colleges and universities from across the countries which are offering the MBBS course.<br />The students, who have cleared the 10+2 examination and they had the Physics, Chemistry and Biology in 12th stream, may go for the MBBS degree course.<br />The MBBS is the only course in India to become a medical doctor. The MBBS course contains the basic subjects like physiology, biochemistry, microbiology, anatomy, pharmacology and pathology.<br />It is the course with hands on training with five years long. The students interact with the patient and get the practical knowledge of diseases.<br />The skills required to make a career in MBBS:<br />&bull; Ability to work with a team<br />&bull; Deep interest in being a helping professional<br />&bull; Good Stamina<br />&bull; Responsible Attitude<br />&bull; Patience and Compassion<br />&bull; Constant updating of skills and knowledge<br />&bull; Mental alertness at all times<br />Eligibility &amp; Admission<br />How to get admission into MBBS programme?<br />&bull; To get admission into MBBS programme in India, students have to complete their 10+2 education with Physics, Chemistry &amp; Biology and score minimum 50% marks (40% in the case of reserved category).<br />&bull; Student&rsquo;s age should be between 17 years to 25 years.<br />&bull; The given qualification is not enough to get admission into MBBS course, students have to appear for the National Level Examination conducted by the CBSE, New Delhi, i.e. NEET 2019 (National Eligibility Cum Entrance Test). Students also apply for AIIMS 2019 &amp; JIPMER 2019 MBBS Entrance Exam to get admission into MBBS programme.<br />&bull; From the year 2016, the Supreme Court bans the state level or university level examinations for admission into MBBS &amp; BDS courses.<br />&bull; Now, all the admission into MBBS course through NEET Exam.<br />Also Check:<br />Top Medical Entrance Exams<br />Top Universities/Institutions in India offer MBBS Course:<br />&bull; All India Institute of Medical Sciences (AIIMS)<br />&bull; Armed Forces Medical College (AFMC)<br />&bull; Jawaharlal Institute of Post Graduate Medical Education and Research (JIPMER)<br />&bull; Christian Medical College (CMC)<br />&bull; Maulana Azad Medical College, New Delhi<br />&bull; King George&rsquo;s Medical University, Lucknow<br />Career &amp; Jobs<br />After the completion of the MBBS course, the first question arise in your mind &ldquo;What after MBBS?&rdquo;<br />The medical graduates are entitled to use the term Doctor before his or her name as the prefix &ldquo;Dr&rdquo;.<br />Day by Day, the demand of medical professionals is increasing due to the unfortunate upsurge in diseases and ailments.<br />Career in MBBS &amp; higher studies is very rewarding for the students, those interested in science and dealing with treating sick peoples.<br />For the better prospect of your career you should have some skills like deep knowledge in the field, good diagnosing ability, responsibility, self-confidence, caring nature, counseling skill and good communication so as to interact with your patients.<br />There are good job and career opportunities for the students after getting the degree in medical as a doctor. It is the professional field with 100% job placement. No one in the country, who has the MBBS degree and has no job.<br />An MBBS graduate may go for the PG degree programmes leading to the Domain M.D (Doctor of Medicine) or M.S (Master of Surgery) or M.Sc (Medical) etc.<br />After completing the MBBS degree successfully, there are two options for the students: either start their own venture or go for a job in the medical field. Students can also go for the government jobs as a doctor or join a private health firm. There are good future scopes in the field of medical.<br />You may be hired by the medical college, hospitals, nursing home, health corporations, health ministry, medical health society, back office medical consultancy and pharmaceutical industries. You can also work as physician, prescribes medicines &amp; treatment for disease, research while surgeons perform operations.<br />ADMISSION OPEN 2019<br />1. Preparig for NEET 2020 - Join Aakash Institute. APPLY NOW &gt;<br />2. Uttaranchal University - Medical Courses Admission Open 2019. APPLY NOW &gt;<br />Many Medical Graduates are much in demand to study &amp; research the different areas in Bio-Engineering.<br />The job profiles of the MBBS may be the following:<br />&bull; Junior doctors<br />&bull; Doctors<br />&bull; Physician<br />&bull; Junior Surgeons<br />&bull; Medical Professor or Lecturer<br />&bull; Researcher<br />&bull; Scientist<br />Some Employment Areas are given here:<br />&bull; Hospitals<br />&bull; Laboratories<br />&bull; Biomedical Companies<br />&bull; Nursing Homes<br />&bull; Medical Colleges<br />&bull; Health Centres<br />&bull; Pharmaceutical and Biotechnology Companies<br />Salary<br />How much money can you make after you have completed your MBBS?<br />After completing the MBBS degree, every student wants to know how much they will earn. The salary of the MBBS degree holder is depends upon how much knowledge &amp; experience you have. The initial salary of a medical graduate doctor may be the Rs. 20,000 to Rs. 35,000 per month. After getting the experience and good hands on in this field, the candidate may get the handsome salary as 8 to 10 lakh per annum.<br />There are more job opportunities to work in the US and the UK in medical field with handsome salaries.<br />Books &amp; Study Materials<br />Here we have mentioned some most preferred books to study MBBS:<br />Physiological basis of medical practice by Best and Taylor<br />Biochemistry for Medical students by D.M.Vasudevan &amp; Shree Kumari<br />Clinical anatomy for medical students by Richard Snel<br />Park&rsquo;s Text book of preventive and social medicine by K.Park<br />Textbook of medical biochemistry by Mn Chatterjea</p>
 <p><h2>CBI</h2><br />If you are dreaming to become an Officer in CBI, you must pass the Combined Graduate Level Examination (CGL ) conducted by Staff Selection Commission (SSC) in every year. It is a 4 tier examination which includes two online objective type exams and one descriptive type using pen and paper. Final stage is document verification.<br /><br />Eligibility:<br />The age limit to apply for Sub Inspector in Central Bureau Of Investigation (CBI ) is 20-30 years.<br />Education Qualification<br />1. Must have a Bachelor's Degree from a Recognized University.<br />Pay Scale<br />The salary scale of Sub Inspector in CBI is 9300 &ndash; 34800 Indian Rupees per month and the CBI Inspector lies with in the Grade Pay of 4200 Rupees and the total in hand salary per month is 44000.<br />CBI recruits candidates through direct recruitment, deputation, promotion by seniority or through Limited Departmental Competitive Examination. All direct recruitment of Group C posts for Sub-Inspectors, Constables and Lower Division Clerk are made through Staff Selection Commission (SSC).<br /><br />Procedure to join in CBI as sub inspector :<br />Sub Inspectors are recruited through SSC's Combined Graduate Level Examination (CGLE), followed by medical examination and personal interview.<br />Candidates holding graduate degree from any recognised university and age limit between 20 to 25 years can apply for Combined Graduate Level Examination which is conducted in two levels :<br />&bull; Tier -I : Written Examination (Objective Multiple Choice Type)<br />Tier I will be of 2 hours duration with a total marks of 200. The paper include in this section are General Intelligence + Reasoning (50 marks); General Awareness (50marks); Quantitative Aptitude (50 marks) and English Comprehension (50 marks)<br />&bull; Tier -II : Written Examination (Objective Multiple Choice Type) <br />Tier II carries a total of 400 marks with 2 papers, each of 2 hours duration. The first paper carrying 200 marks, contains 100 question from Quantitative Abilities and the second paper include English Language and Comprehension.</p>
 <p><h2>IPS &ndash; How can you get into the Indian Police Service?</h2></p>
 <p>Do you love the police uniform? Is your ambition to become an IPS officer? In this post, we shall see how can you become an IPS officer. We shall also cover the eligibility criteria and the medical requirements for IPS.<br />IPS Full Form: What is the full form of IPS?<br />The full form of IPS is Indian Police Service.<br />Officers of the Indian Police Service (IPS) provide senior level leadership to Police Forces &ndash; both in the States and at the Centre.<br />The legacy of the Indian Police Service (IPS)<br />Origin of the Indian Police Service can be traced back to the Indian (Imperial) Police) during the British rule in India. In 1948, a year after India gained independence from Britain, the Indian (Imperial) Police, was replaced by the Indian Police Service.<br />Indian Police Service in the Indian Constitution<br />Once the Indian Constitution was written (1950), the Indian Police Service (IPS) was constituted under Article 312 of the Constitution of India as one of the three All India Services (AIS). The other two All India Services (AIS) are Indian Administrative Service (IAS) and Indian Forest Service (IFS).<br />IPS Exam: Which exam should you write to get into IPS?<br />To get into Indian Police Service (IPS), you need to clear Civil Services Exam (CSE)conducted by the Union Public Services Commission (UPSC) with high marks.<br />Civil Service Exam (CSE) is a common exam conducted by UPSC for the recruitment of candidates to various services like IAS, IPS, IFS, IRS etc.<br />Candidates in the age group 21-32 years can appear for the exam. There is relaxation in the age limit for OBC, SC, and ST candidates. You just need to be a graduate to appear for the Civil Services Exam. Read more about the Civil Services Exam eligibility criteria here.<br />Civil Services Exam has three stages &ndash; Prelims, Mains, and Interview. There will be a medical test on the next day after the UPSC Interview.<br />Indian Police Service is a technical service, and candidates will not be accepted if they do not meet the minimum standard for height and chest girth.<br />IPS Height Requirement<br />Minimum Height Required for Male Candidates: 165 cm<br />Minimum Height Requirement for Female Candidates: 150 cm<br />However ST candidates have a relaxation of 5 cm, hence the requirement is only 160 centimetres for ST male candidates and 145 centimetres of ST female candidates. Relaxed minimum height is prescribed not only for candidates belonging to Scheduled Tribes but also to races such as Gorkhas, Garhwalis, Assamese, Kumaonis, and Nagaland Tribal etc. whose average height is distinctly lower.<br />IPS Chest Girth Requirement<br />Chest girth when fully expanded for male candidates: 84 cm<br />Chest girth when fully expanded for female candidates: 79 cm.<br />Candidates should also be able to expand chest size by 5 cm.<br />Indian Police Service Eyesight Requirement<br />Distant Vision: For the better eye, the corrected vision should be 6/6 or 6/9. For the worse eye, the corrected vision should be 6/12 or 6/9.<br />Near Vision: For the better eye, the corrected vision should be J1**. For the worse eye, the corrected vision should be J2**.<br />About Corrections permitted: Correction like Spectacles, CL and Refractive Surgery like Lasik, ICL, IOL etc are permitted. However, if refractive surgery was done, the case to be referred to a Special Board of Ophthalmologists.<br />About Refractive errors permitted: There is no such limit. However, the candidates who have Myopia of more than 6.00 D including spherical &amp; cylindrical error should be referred to special Myopia Board.<br />Note: You are declared unfit for IPS if you have a squint. Also, you need to have binocular vision and high-grade colour vision to be medically fit for IPS.<br />How many IPS officers will be selected by UPSC every year?<br />150.<br />How many IPS officers are there in India (in total)?<br />The Authorized strength of the Indian Police Service Officers is only 4802. Out of this authorized strength, many posts are remaining vacant.<br />This means that once you get into the Indian Police Service, you occupy an unmatchable position. You will become part of a top leadership group, capable of commanding various police forces.<br />Is there any other way, apart from UPSC CSE, one can get into IPS?<br />At present, there are three modes of recruitment to the Indian Police Service. These are as follows:<br />1. Through the Civil Services Examination conducted by Union Public Service Commission.<br />2. Through Limited Competitive Examination conducted by Union Public Service Commission (very rarely conducted).<br />3. Through the appointment of State Police Service officers by promotion (by means of promotions from state police).<br />As you now know, a few officers of state police get promotion will be conferred IPS. However, to get IPS in this route, it needs a lot of experience and excellent track record. On the contrary, direct recruits get IPS at a young age if he/she clears UPSC Civil Services Exam.<br />Training for Indian Police Service Officers<br />All the officers of Indian Police Service undergo probationary training at Lal Bahadur Shastri National Academy of Administration, Mussoorie and Sardar Vallabhbhai Patel National Police Academy, Hyderabad. After successful completion of probation, officers are confirmed in the service.<br />Also, there is a provision for mandatory Mid Career Training for Indian Police Service officers spread across the entire service span.<br />The Police Division in the Ministry of Home Affairs (MHA) is responsible for Cadre management of Indan Police Service and Policy Decisions such as cadre structure, recruitment, training, cadre allocation, confirmation, empanelment, deputation, pay and allowances, disciplinary matters of Indian Police Service Officers. The Service is organized in 26 State cadres, reviewed after every 5 years.<br />IPS Salary: What is the salary of an Indian Police Service Officer?<br />The salary of an IPS officer is very much comparable the salary of an IAS officer, with only minor differences.<br />An entry level IPS officer (ASP rank) gets a basic pay of Rs.56100 while the highest rank officer (DGP) will get Rs.2,25,000. Allowances like DA, TA etc are provided in addition to the basic pay.<br />Indian Police Service officers are eligible for raise in salary and promotions in their career span. The promotions take place after evaluating the performance on the basis of Annual Performance Appraisal Reports, Vigilance Clearance and scrutiny of the overall record of the officer.<br />Will Indian Police Service officers get challenging roles, other than in police?<br />Indian Police Service officers can be appointed in autonomous organizations/ sub-ordinate organizations/ PSUs/ UN Organizations/ International Organizations in various capacities.<br />They can also serve as Personal Secretaries to Ministers in Central Government.<br />IPS officers lead and command the Central Armed Police Forces (CAPF) which include the Central Police Organisations (CPO) and Central Paramilitary Forces (CPF) such as Border Security Force (BSF), Central Reserve Police Force (CRPF), Indo-Tibetan Border Police (ITBP), National Security Guard (NSG), Central Industrial Security Force (CISF), Vigilance Organisations, Indian Federal Law Enforcement Agencies.<br />Officers of Indian Police Service also lead and command the Indian Intelligence Agencies like Research and Analysis Wing (R&amp;AW), Intelligence Bureau (IB), Central Bureau of Investigations (CBI), Criminal Investigation Department (CID) etc.</p>
 <p><h2>Teacher</h2></p>
 <p>you need to do 1 year B.Ed program from any recognised university and after that you have to apply for TET (Teacher Eligibility Test) entrance exam.<br />&bull; Candidate needs to be graduate in any stream.<br />&bull; Minimum 50% of marks needed in order to get admission.<br />&bull; In some institutes/universities admissions took place on basis of written test.<br />After completing B.Ed course you need to qualify the TET entrance examination in order to get Teacher Job in Government school.<br />If you do MSc after BSc then you also have a chance to become professor in Government colleges. After completing M.Sc course you need to appear and qualify in CSIR NET exam which is conducted by UGC.<br />Eligibility Criteria for CSIR NET:<br />&bull; Candidates completed their Master degree with minimum 55% are eligible to apply for CSIR NET exam.<br />&bull; Applicants&rsquo; age should be less than or equal to 28 years for Junior Research Fellowship.<br />&bull; There is no age limit for Lectureship.</p>
 <p><br /><h2>MEDICAL LABORATORY TECHNOLOGY COURSE</h2><br />Admissions open for Medical Technology Technician (MLT) course<br />Join the Medical Lab Technician course and work towards building a career in the healthcare industry.<br />Course affiliated with the Indian Medical Association (IMA).</p>
 <p>Medical Lab Technician Course Details<br />Medical Lab Technician Course Objective and Curriculum<br />The Medical Lab Technician (MLT) course trains students to work as full-fledged lab technologists capable of collecting and storing samples, analysing them and creating reports based on the sample for further analysis by a doctor. The course includes elements of blood bank management, materials management, supply chain management as well as lab information system management. Additionally, graduates from this course are trained to clean and maintain lab equipment, manage biomedical waste and adhere to quality control standards as per the NABL regulations.<br />The MLT course curriculum covers the following topics<br />&bull; Introduction to patient care, lab technology and equipment<br />&bull; Basic pathology and diagnostic techniques<br />&bull; Basic &amp; clinical biochemistry<br />&bull; Basic &amp; systemic medical microbiology<br />&bull; General pharmacology<br />&bull; Basic haematology, immunology, parasitology and histology<br />&bull; Blood banking<br />&bull; Phlebotomy and handling special samples<br />&bull; Fine needle aspiration technique<br />&bull; Storage &amp; transportation of samples<br />&bull; Lab information management system<br />&bull; Preparation and documentation of medical tests &amp; results<br />&bull; Biomedical waste management<br />&bull; Infection control<br />&bull; Materials management &amp; supply chain management<br />&bull; Maintenance and cleaning of lab equipment<br />&bull; NABL training &amp; quality control<br /></p>
 </div>
 </div>
 </div>
 </div><!-- modal-conten -->
 </div><!-- modal-dialo -->
</div><!-- modal -->
                                    
                                    

                                    
<!-- 
</div>
<script type="text/javascript">
$("#pop").on("click", function() {
   $('#imagepreview').attr('src', $('#imageresource').attr('src')); // here asign the image to the modal when the user click the enlarge link
   $('#Modal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
});
</script>
<!-- JavaScript  files ========================================= -->
<script  src="js/jquery.min.js"></script>
<!-- jquery.min js -->
<script  src="js/bootstrap.min.js"></script>
<!-- bootstrap.min js -->
<script src="js/jquery.countdown.js"></script>
<!-- jquery countdown -->
<script src="js/scrollbar.min.js"></script>
<!-- custom fuctions  -->
<script src="js/coming-soon.js"></script>
<!-- custom fuctions  -->



</body>
</html>

