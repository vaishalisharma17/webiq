<?php
/* Set e-mail recipient */
$myemail = "";

/* Check all form inputs using check_input function */
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['subject'];
$subject ="New Inquiry";
$messagee=$_POST['message'];


$from = 'info@iq19-24.com';

/* If e-mail is not valid show error message */
if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $email))
{
show_error("E-mail address not valid");
}
/* Let's prepare the message for the e-mail */
$message = "

Name: $name

E-mail: $email

Contact No.: $contact

Message: $messagee


";

/* Send the message using mail() function */

if(mail($myemail,$subject,$message))
{
//echo "mail sent";
/* Redirect visitor to the thank you page */
header('Location: index.php');
exit();
}

function show_error($myError)
{ 
?>
<html>
<body>

<p>Please correct the following error:</p>
<strong><?php echo $myError; ?></strong>
<p>Hit the back button and try again</p>

</body>
</html>
<?php
exit();
}
?>