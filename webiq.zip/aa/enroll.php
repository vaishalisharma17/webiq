<!DOCTYPE HTML>
<html lang="zxx">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table, th, td {
border: 1px solid black;
}
.button1 {
background-color: #c11b71;
padding: 15px 32px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
border: none;
color: white;
} 
.modal-header
{
color:white;
background-color:#c11b71 ;
}
.modal-body
{
color:#c11b71;
background-color:white;
}
#b1 {
background-color: white;
padding: 15px 32px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
border: none;
color: black;
} 

.blin
{
animation:blinkText 0.9s infinite;
}
@keyframes blinkText{
    0%{     color: black;    }
    50%{    color: white; }
    100%{   color: black;    }
}
#dateofbirth
{
  background:#fff url(images/calendar.png)  97% 50% no-repeat ;
}
[type="date"]::-webkit-inner-spin-button {
  display: none;
}
[type="date"]::-webkit-calendar-picker-indicator {
  opacity: 0;
}
</style>
<title>Enroll yourself</title>
    <!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8" />
<meta name="keywords" content="Triple" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script type="text/javascript">
var citiesByState = {
AndhraPradesh: ["Era International School Anantapur",
"Global Wisdom International School ",
"Hyderabad Public School",
                                      "Little Angels Public School",
                                      "Little Bells EM High School",
                                      "Little Lights Free Education High School",
                                      "Loyola High School",
                                      "Loyola High School",
                                      "Loyola High School",
                                      "Loyola Public School",
                                      "Priyadarshini High School",
                                      "Ratnam Concept School",
                                      "Sainik School Korukonda",
                                      "Saint Charles English Medium High School",
                                      "St Johns High School",
                                      "St Xaviers College of Education",
                                      "St Xaviers High School",
                                      "Sasi Merit School",
                                      "Satavahana College",
                                      "Sir CRReddy High School",
                                      "SPNRC High School",
                                      "Sri Chaitanya Techno School",
                                      "Sri Sathya Sai Vidya Vihar",
                                      "Sri Venkateswara Bala Kuteer",
                                      "Sri Vidya Nilayam High School",
                                      "Timpany School Asilmetta",
                                      "Srikrishna Vidya Mandir",
                                      "VBR English Medium High School",
                                      "Vijnana Vihara School",
                                      "Viswa Bharathi English Medium High School" ],
ArunachalPradesh: ["Government Higher Secondary School",
                                      "Government Secondary School Rani",
                                      "Independent Golden Jubilee Government Higher Secondary School Pasighat"],
Assam: ["Don Bosco High School Guwahati",
                                      "Faculty Higher Secondary School Amingaon",
                                      "Holy Child School Guwahati",
                                      "Jawahar Navodaya Vidyalaya Pailapool",
                                      "Kendriya Vidyalaya 9th Mile Guwahati",
                                      "Kendriya Vidyalaya Khanapara",
                                      "Kendriya Vidyalaya Maligaon",
                                      "St Francis de Sales School Dhemaji",
                                      "St Mary English High School Guwahati",
                                      "Sainik School Goalpara",
                                      "Spring Dale High School",
                                      "Jorhat Govt Boys HS and MP School",
                                      "Nalbari Govt Gurdon HS School"],
Bihar: ["Delhi Public School Bhagalpur",
                                      "Mount Assisi School",
                                      "St Josephs School Bhagalpur",
                                      "St Josephs School Pakartalla Kahalgaon",
                                      "Ark International School Begusarai",
                                      "BL Indo Anglian Public School Aurangabad",
                                      "Bivha International School",
                                      "GA Inter School Hajipur",
                                      "Jawahar Navodaya Vidyalaya West Champaran",
                                      "Jayant Academy Raxaul",
                                      "Jhajha Public School Jhajha",
                                      "Jyothi Central High School Ekma",
                                      "Khrist Raja High School Bettiah",
                                      "M P T High School Jhanjharpur",
                                      "Manas International Public School Jehanabad",
                                      "Progressive School Barh Barh",
                                      "Rose Public School Darbhanga",
                                      "Sainik School Gopalganj Gopalganj",
                                      "Sainik School Nalanda Nalanda",
                                      "St Pauls High School Hajipur",
                                      "St Xaviers Higher Secondary School Bettiah",
                                      "Sir Syed Memorial School Gaya",
                                      "Watson High School Madhubani"],
Chhattisgarh: ["Bastar High School",
                                      "DAV Public School Bhillai",
                                      "Delhi Public School Bilaspur",
                                      "Delhi Public School Durg",
                                      "DAV Public School Nandini Mines",
                                      "DAV Public School Rajhara District-Balod",
                                      "Holy Cross Senior Secondary School Kapa",
                                      "Jawahar Navodaya Vidyalaya Basdei",
                                      "Rajkumar College Raipur",
                                      "Royal Kids Convent",
                                      "Sainik School Ambikapur"],
Goa: ["Assagao Union High School",
                                      "Little Flower of Jesus High School",
                                      "Loyola High School",
                                      "Regina Mundi High School Chicalim",
                                      "Saint Britto High School Mapusa",
                                      "St Britto Goa",
                                      "St Marys Convent High School Mapusa Goa",
                                      "SFX High School Siolim Goa",
                                      "Sharada Mandir School Panjim",
                                      "Shree Damodar Higher Secondary School of Science"],
Haryana: ["Apollo International School Sonipat",
                                      "Campus School CCS HAU Hisar",
                                      "Gita Niketan Awasiya Vidyalaya Kurukshetra",
                                      "Hardayal Public School Bahadurgarh",
                                      "Motilal Nehru School of Sports Rai",
                                      "Rishikul Vidyapeeth Sonipat",
                                      "Vidya Devi Jindal School Hisar",
                                      "Bharti International Convent School",
                                      "Blue Bells Model School",
                                      "Gurugram Public School",
                                      "Shalom Hills International School",
                                      "The Shri Ram School",
                                      "Vega Schools",
                                      "Apeejay School Sector 15",
                                      "Carmel Convent School Sector 7D",
                                      "Delhi Public School Sector 19",
                                      "Eicher School Sector 46",
                                      "Modern Vidya Niketan schools",
                                      "Ryan International School",
                                      "SOS Hermann Gmeiner School Sector 29"],
HimachalPradesh: ["Alpine Public School Nalagarh Himachal Pradesh",
                                      "Army Public School Dagshai",
                                      "Auckland School Shimla",
                                      "Bhartiya Public Senior Secondary School Joginder Nagar",
                                      "Bishop Cotton School",
                                      "Chail Military School",
                                      "Chinmaya Vidyalaya Nauni",
                                      "DAV Centenary Public School Mandi",
                                      "Dalhousie Hilltop School Dalhousie",
                                      "Him Academy Public School Hamirpur",
                                      "Indus World School Mandi",
                                      "International Sahaja Public School",
                                      "Jawahar Navodaya Vidyalaya Theog",
                                      "Lawrence School Sanawar Kasauli",
                                      "Loreto Convent Tara Hall Shimla",
                                      "Pinegrove School",
                                      "Sacred Heart High School Dharamshala",
                                      "St Edwards School Shimla",
                                      "St Lukes Senior Secondary School",
                                      "St Marys Convent School Kasauli",
                                      "Shimla Public School Shimla",
                                      "V R Senior Secondary Public School Baddi"],
JammuandKashmir: ["BSF Senior Secondary School Jammu",
                                      "Burn Hall School Srinagar",
                                      "Christ School Poonch",
                                      "Delhi Public School Srinagar",
                                      "Dr AGMs City School Srinagar",
                                      "Druk White Lotus School Shey Ladakh",
                                      "Green Valley Educational Institute",
                                      "KC International School",
                                      "Lal Ded Memorial School",
                                      "Little Angels High School Srinagar",
                                      "Mallinson Girls School Srinagar",
                                      "Nawaz Public Higher Secondary School Palam Rajauri",
                                      "Presentation Convent Higher Secondary School Srinagar",
                                      "Presentation Convent Senior Secondary School Jammu",
                                      "Sainik School Manasbal",
                                      "Sainik School Nagrota",
                                      "St Josephs School Baramulla",
                                      "St Peters High School Jammu",
                                      "Saint Solomon High School",
                                      "Sharon Public Higher Secondary School Ambedkar Colony Rount Udhampur",
                                      "SMD High School",
                                      "Sri Pratap Higher Secondary School",
                                      "Tyndale Biscoe School Srinagar"],
Jharkhand: ["Bokaro Public School",
                                      "Carmel School Digwadih Dhanbad",
                                      "Carmel Junior College Jamshedpur",
                                      "Chasnalla Academy Chasnalla",
                                      "DAV Centenary Public School Bhawanathpur Township",
                                      "De Nobili School Bhuli Dhanbad",
                                      "De Nobili School CMRI Dhanbad",
                                      "De Nobili School CTPS Bokaro Chandrapura",
                                      "De Nobili School FRI Digwadih Dhanbad",
                                      "De Nobili School Maithon Dhanbad",
                                      "De Nobili School Mugma Dhanbad",
                                      "De Nobili School Sijua",
                                      "De Nobili School Sindri Dhanbad",
                                      "Delhi Public School Bokaro",
                                      "Delhi Public School Dhanbad",
                                      "Loyola School Jamshedpur",
                                      "The Pentecostal Assembly School Bokaro",
                                      "St Xavier School Bokaro",
                                      "Sree Ayyappa Public School Bokaro Steel City",
                                      "Bishop Westcott Boys School",
                                      "Bishops School",
                                      "Central Academy",
                                      "DAV Public School",
                                      "DAV Kapil Dev Public School",
                                      "Delhi Public School",
                                      "Guru Nanak Higher Secondary School",
                                      "Jawahar Vidya Mandir",
                                      "Kairali School",
                                      "Kendriya Vidyalaya",
                                      "Oxford Public School",
                                      "St Anthonys School",
                                      "St Francis School Harmu",
                                      "St Johns High School",
                                      "StThomas School",
                                      "St Xaviers School",
                                      "Surendranath Centenary School",
                                      "Taurian World School",
                                      "Vikas Vidyalaya",
                                      "Vivekananda Vidya Mandir",
                                      "Kendriya Vidyalaya"],
Karnataka: ["Greenwood High International School Bangalore",
                                      "Jain Heritage School Bangalore",
                                      "Jain International Residential School Bangalore",
                                      "Loyola Pre-University College Manvi Raichur",
                                      "Loyola School & PU College Mundgod",
                                      "Loyola Yomiuri School Bijapur",
                                      "Nutan Vidyalaya Education Society Gulbarga",
                                      "St Aloysius College Mangalore",
                                      "St Aloysius PU College Harihar",
                                      "St Joseph School Anekal",
                                      "St Josephs PU College Anekal",
                                      "St Josephs School Hassan",
                                      "St Pauls School Belgaum",
                                      "St Marys School Belgaum",
                                      "St Xaviers PU College Gulbarga",
                                      "Trio World Academy Bangalore",
                                      "Vidyashilp Academy Bangalore",
                                      "Xavier School Manvi Raichur"],
Gujarat: ["Ahmedabad International School",
                                      "Best High School (Ahmedabad)",
                                      "Delhi Public School Bopal",
                                      "Diwan-Ballubhai School",
                                      "Doon International School (Ahmedabad)",
                                      "Mahatma Gandhi International School Ahmedabad",
                                      "Mount Carmel High School Ahmedabad",
                                      "Mount Carmel High School Gandhinagar",
                                      "Prakash Higher Secondary School",
                                      "Saraswat School of Science Ghatlodia",
                                      "St Anns School Ahmedabad",
                                      "St Xaviers High School Mirzapur",
                                      "Sheth Chimanlal Nagindas Vidyalaya",
                                      "Zydus School for Excellence",
                                      "Rajkumar College Rajkot",
                                      "Baroda High School Alkapuri",
                                      "Navrachana School",
                                      "Podar World School",
                                      "Rosary High School",
                                      "Vibgyor High School",
                                      "Ashadeep Group of Schools",
                                      "St Xaviers High School Surat",
                                      "A G High School",
                                      "Alfred High School Bhuj",
                                      "Alfred High School Rajkot",
                                      "Crescent National High School (Gujarat)",
                                      "Pioneer High School Anand",
                                      "Rajratan Purshotoom Tribhuvandas Patel High School",
                                      "St Francis of Assisi Convent High School",
                                      "St Xaviers Adipur",
                                      "Saraswati International School"],
Kerala: ["AGRM Higher Secondary School Vallikunnam",
                                      "Aji Senior Secondary School Uppala",
                                      "AKJM Public School Kanjirappally Kottayam",
                                      "A L P School Kokkadavil",
                                      "Anjarakandy Higher Secondary School",
                                      "Ansar English School Thrissur",
                                      "Arya Bharati High School Omallur",
                                      "Auxilium ISC School Kottiyam",
                                      "Basel Evangelical Mission Parsi High School Thalassery",
                                      "BEM High School Parappanangadi",
                                      "Bishop Moore Vidyapith Cherthala",
                                      "BMM English Medium School Pampady",
                                      "Brook International School Sasthamcotta",
                                      "Chaldean Syrian Higher Secondary School Thrissur",
                                      "The Charter School Pukkattupady Kochi",
                                      "The Charter School Trivandrum",
                                      "Chinmaya Vidyalaya Kozhikode",
                                      "CVKM Higher Secondary School",
                                      "Global Public School Cochin",
                                      "Govt Ganapath High School for Boys",
                                      "Hari Sri Vidya Nidhi School",
                                      "Holy Angels ISC School Trivandrum",
                                      "Infant Jesus Anglo-Indian Higher Secondary School Kollam",
                                      "John Joseph Murphy Memorial Higher Secondary School Yendayar",
                                      "Kendriya Vidyalaya Pangode",
                                      "Lemer Public School",
                                      "Loyola School Trivandrum",
                                      "MMHSS Thalassery Thalassery",
                                      "Montfort School Anakkara",
                                      "Mount Carmel Convent Anglo-Indian Girls High School Kollam",
                                      "Nirmala Higher Secondary School Muvattupuzha",
                                      "Nirmala Higher Secondary School Chemperi",
                                      "Rajarshi Memorial Higher Secondary School",
                                      "Sacred Heart Girls High School",
                                      "Sainik School Kazhakootam",
                                      "St Augustines Higher Secondary School Karimkunnam",
                                      "St Francis Sales Central School",
                                      "St Josephs Convent School Kalpetta",
                                      "St Josephs Higher Secondary School Thalassery",
                                      "St Marys Residential Central School",
                                      "St Michaels School Kannur",
                                      "St Peters School Kadayiruppu",
                                      "St Stephens School Pathanapuram",
                                      "St Thomas Convent School Palakkad",
                                      "Seventh-day Adventist Higher Secondary School Kochi",
                                      "Technical Higher Secondary School Cherthala",
                                      "Udyogamandal School",
                                      "Vidyadhiraja Vidya Bhavan Higher Secondary School Aluva"],
MadhyaPradesh: ["Army Public School Mhow",
                                      "Campion School Bhopal",
                                      "Christ Church Boys Senior Secondary School",
                                      "Delhi Public School Bhopal",
                                      "Gyankriti School Indore",
                                      "Himalaya International School Ratlam",
                                      "Gwalior Glory High School Gwalior",
                                      "Little Angels High School Gwalior",
                                      "Kendriya Vidyalaya No 1 ",
                                      "Kendriya Vidyalaya Guna Madhya Pradesh",
                                      "Kendriya Vidyalaya Shivpuri Madhya Pradesh",
                                      "Kiddys Corner School Gwalior",
                                      "Mahesh Memorial Public Higher Secondary School Bagh",
                                      "Rajeev Gandhi Memorial Boarding School Sheopur",
                                      "St Aloysius Senior Secondary School",
                                      "St Francis Higher Secondary School Pithampur",
                                      "St Josephs Convent School Bhopal",
                                      "StPaul Higher Secondary School Indore",
                                      "St Raphaels Girls Higher Secondary School Indore",
                                      "The Sanskaar Valley School Bhopal",
                                      "Vidya Niketan School Chhindwara"],
Maharashtra: ["Bims Paradise English High School",
                                      "St Xaviers High School",
                                      "D A V Public School",
                                      "Dnyaneshwar Dnyan Mandir High School And Junior College",
                                      "Hiranandani Foundation School",
                                      "Holy Cross Convent High School",
                                      "Little Flower High School",
                                      "Model English High School",
                                      "New Horizon Scholars School Thane",
                                      "Saraswati Education Society High School and Junior College (SES)",
                                      "Smt Sulochanadevi Singhania School",
                                      "St John the Baptist High School",
                                      "Vasant Vihar High School",
                                      "RP Mangala Hindi High School"],
Manipur: ["DAV Public School",
                                      "Don Bosco High School Imphal",
                                      "Hamai English High School",
                                      "Ideal English School",
                                      "Jawahar Navodaya Vidyalaya Pfukhro Mao",
                                      "Johnstone Higher Secondary School Imphal",
                                      "Little Flower School",
                                      "Padma Ratna English School",
                                      "Sainik School Imphal",
                                      "St Josephs School Imphal"],
Meghalaya: ["Christian Girls Higher Secondary School Tura",
                                      "Don Bosco Technical School Shillong",
                                      "St Anthonys Higher Secondary School Shillong",
                                      "St Edmunds School Shillong"],
Mizoram: ["Bethel Mission School Champhai",
                                      "Government Higher Secondary School Serchhip",
                                      "Home Missions School Aizawl",
                                      "Nuchhungi English Medium School Hnahthial",
                                      "Synod Higher Secondary School Aizawl"],
Nagaland: ["Don Bosco Higher Secondary School",
                                      "Edith Douglas Higher Secondary School",
                                      "Immanuel School Zunheboto",
                                      "Sainik School Punglwa"],
Odisha: ["Aditya Birla Public School Rayagada",
                                      "Aditya Birla Public School Bhubaneswar",
                                      "Badagada Government High School Bhubaneswar",
                                      "Balangir Public School Balangir",
                                      "Bhargabi High School Puri district",
                                      "Blessed Sacrament High School Puri",
                                      "Capital High School Bhubaneswar",
                                      "Carmel School Rourkela",
                                      "Chinmaya Vidyalaya Rourkela",
                                      "DAV Public School Chandrasekharpur Bhubaneswar",
                                      "Dabugaon Girls High School Nabarangpur",
                                      "DAV Public School Rourkela",
                                      "DAV Public School Unit-8 Bhubaneswar",
                                      "DAV Public School Cuttack",
                                      "Deepika English Medium School Rourkela",
                                      "Delhi Public School Khariar Road",
                                      "Delhi Public School Rourkela",
                                      "Demonstration Multipurpose School Bhubaneswar",
                                      "Desouzas School Rourkela",
                                      "Doon International School (Bhubaneswar)",
                                      "GCD High School Rayagada",
                                      "Government High School Uditnagar Rourkela",
                                      "Govt Girls High School Rayagada",
                                      "Govt High School Mathili",
                                      "Govt BNHigh School Padmapur",
                                      "G S High School",
                                      "Government High School Saheed Nagar",
                                      "Harobino Vidya Bhavan",
                                      "Indo English School Rourkela",
                                      "Ispat English Medium School Rourkela",
                                      "Jawahar Navodaya Vidyalaya Bagudi",
                                      "Jawahar Navodaya Vidyalaya Mundali",
                                      "Jawahar Navodaya Vidyalaya Narla",
                                      "Jobra High School Cuttack",
                                      "Kendriya Vidyalaya No1 Bhubaneswar",
                                      "Kendriya Vidyalaya Charbatia Cuttack",
                                      "Kendriya Vidyalaya Rourkela",
                                      "Kendriya Vidyalaya Sundargarh",
                                      "Khariar Public School Khariar",
                                      "KIIT International School Bhubaneswar",
                                      "Little Angels Senior Secondary School Brajrajnagar",
                                      "Loyola School Baripada",
                                      "Loyola School Bhubaneswar",
                                      "MN High School Pattamundai",
                                      "Maharaja High School Sonepur",
                                      "MahaRajas Boys High School Paralakhemundi",
                                      "Mahatma Gandhi High School Sheragada",
                                      "Matrusree Anglo Vedic School Berhampur",
                                      "MGM English Medium School Rourkela",
                                      "Montfort School Kansbahal",
                                      "Pragati Vidya Mandir",
                                      "Puri Zilla School Puri",
                                      "Raja Basudev High School Debagarh",
                                      "Ravenshaw Collegiate School Cuttack",
                                      "Sai International School Bhubaneswar",
                                      "SAI International Residential School Bhubaneswar",
                                      "Sainik School Bhubaneswar",
                                      "Sandeepani Vidyapeeth Balasore",
                                      "Saraswati Vidya Mandir (Rourkela)",
                                      "SDMT Prabhavati Public School Titilagarh",
                                      "Secondary Board High School Cuttack",
                                      "Sri Aurobindo School Sambalpur",
                                      "Sri Aurobindos Rourkela School  Rourkela",
                                      "St Annes Convent School Baripada",
                                      "St Josephs Convent Higher Secondary School Sambalpur",
                                      "St Josephs Convent School Sundergarh",
                                      "St Josephs School Kendrapara",
                                      "St Lawrence School Tentoloi Angul",
                                      "St Marys Higher Secondary School Jharsuguda",
                                      "St Vincents Convent School Balasore",
                                      "St Vincents Convent School Brahmapur",
                                      "St Xaviers High School Rayagada",
                                      "Stewart School Cuttack",
                                      "Subalaya High School Subalaya",
                                      "Vignan Vidyalaya Rayagada",
                                      "Vikash Convent School Karanjia",
                                      "GovtHigh School TomkaJajapur"],
Punjab: ["Dasmesh Public School Faridkot",
                                      "Delhi Public School Bathinda",
                                      "Eastwood International School Mullanpur Dakha",
                                      "Guru Teg Bahadur Khalsa Senior Secondary School Malout",
                                      "La Foundation School Sangrur",
                                      "Mata Jaswant Kaur Memorial School Badal",
                                      "Mount Litera Zee School Moga",
                                      "National High School Patiala",
                                      "Our Lady Of Fatima Convent Secondary School Paliata",
                                      "Ryan International School Patiala",
                                      "Saint Francis High School Amritsar",
                                      "Shivalik Public School Mohali"],
Rajasthan: ["Calorx Public School",
                                      "Jaipur School",
                                      "Jawahar Navodaya Vidyalaya",
                                      "Mahaveer School",
                                      "Maheshwari Public School",
                                      "Mayura School",
                                      "St Anselms North City School",
                                      "St Anselms Pink City Sr Sec School",
                                      "St Xaviers School",
                                      "Tilak Public School Jaipur",
                                      "St Edmunds School Malviya Nagar Jaipur",
                                      "VSI International School",
                                      "The Castle Convent School",
                                      "B R Birla Public School ",
                                      "Netraheen Vikas Sansthan",
                                      "Central Academy Senior Secondary School",
                                      "Rajmata Krishna Kumari Girls Public School",
                                      "Sanskar International School",
                                      "St Annes School Jodhpur",
                                      "Abhay Vidhya Mandir Senior Secondary School Hindaun City",
                                      "B R Birla Public School",
                                      "Delhi Public School Pali",
                                      "Birla Balika Vidyapeeth Pilani",
                                      "Birla Public School Pilani",
                                      "Birla Senior Secondary School Pilani",
                                      "Delhi Public School Jhunjhunu",
                                      "Dholpur Military School",
                                      "Emmanuel Mission Senior Secondary School Jaisalmer Jaisalmer",
                                      "Emmanuel Mission Senior Secondary School Kota Kota",
                                      "Bal Vidyalaya (Kota) Kota",
                                      "Jawahar Navodaya Vidyalaya Jojawar",
                                      "Jawahar Navodaya Vidyalaya Churu",
                                      "Jawahar Navodaya Vidyalaya Patan Sikar",
                                      "Jawahar Navodaya Vidyalaya Jaswantpura",
                                      "Jawahar Navodaya Vidyalaya Mandaphia",
                                      "KS Lodha Public School Falna",
                                      "Lakshmipat Singhania Academy Churu",
                                      "Lala Kamlapat Singhania Education Centre Gotan",
                                      "MG English International School Bagru Bagru",
                                      "National Public School Hanumangarh",
                                      "Nav Prerna School (Sikar Rajasthan) Sikar",
                                      "Prerana Senior Secondary School Nawalgarh",
                                      "Sainik School Chittorgarh",
                                      "St Marys High School Mt Abu",
                                      "St Xaviers School Behror",
                                      "St Xaviers School Bhiwadi",
                                      "St Xaviers School Nevta",
                                      "Solar International School Sanchore",
                                      "Veer Teja Vidhya Mandir School Degana Tehsil",
                                      "VKV Hurda Hurda"],
Sikkim: ["St Francis School Jorethang",
                                      "St Xaviers School Pakyong",
                                      "Taktse International School",
                                      "Tashi Namgyal Academy"],
TamilNadu: ["ARLM Matriculation Higher Secondary School Cuddalore",
                                      "Aiyas Matriculation Higher Secondary School Thirukkalachery Nagapattinam District",
                                      "Akshararbol International School Chennai T-nagar",
                                      "AKT Academy Matriculation Higher Secondary School Kallakurichi",
                                      "American College Higher Secondary School Madurai",
                                      "American International School Chennai",
                                      "Balavihar Matriculation Higher Secondary School Panruti",
                                      "Bapuji Memorial School Kanyakumari",
                                      "Bethlahem Matric School Karungal",
                                      "Bharathi Matriculation Higher Secondary School Kallakurichi",
                                      "Bharathiar Government Higher Secondary School Veeravanallur",
                                      "Breeks Memorial School Charing Cross Ooty",
                                      "Campion Anglo-Indian Higher Secondary School Trichy",
                                      "Carmel High School Nagercoil",
                                      "Carmel Higher Secondary School Nagercoil",
                                      "Chennai Public School Chennai",
                                      "Christhu Jyothi Matric Higher Secondary School Erode",
                                      "De Britto Higher Secondary School Devakottai",
                                      "G K Shetty Hindu Vidyalaya Matriculation Higher Secondary School",
                                      "G V School Chidambaram",
                                      "Good Shepherd International School Ooty",
                                      "Government Higher Secondary School Peruvilai",
                                      "GRG Matriculation Higher Secondary School Coimbatore",
                                      "Hajee Meera Academy",
                                      "Hebron School Ooty",
                                      "Hindu Senior Secondary School Indira Nagar",
                                      "International Community School and Junior College Kotagiri",
                                      "John Paul Higher Secondary School Dindigul",
                                      "Jaycees Matriculation Higher Secondary School Kangeyam",
                                      "Kendriya Vidyalaya Aruvankadu Ooty",
                                      "Kendriya Vidyalaya Indunagar Ooty",
                                      "Kings Matriculation Higher Secondary School Madipakkam",
                                      "The Laidlaw Memorial School and Junior College Ketti Ooty",
                                      "Lakshmi School Madurai",
                                      "Lawrence School Lovedale Ooty",
                                      "Lisieux Matriculation Higher Secondary School Coimbatore",
                                      "Loyola Academy Maraimalai Nagar Chennai",
                                      "Loyola Higher Secondary School Kuppayanallur",
                                      "Mahajana High School Erode",
                                      "Maharajapuram Nagammal Rajaiah Desiya Girls Higher Secondary School",
                                      "Mahatma Montessori Matriculation Higher Secondary School",
                                      "Maria Rafols School Kanyakumari",
                                      "MCTM Chidambaram Chettyar International IB School Chennai",
                                      "Morning Star Higher Secondary School Mica Mount Gudalur",
                                      "Mrs Bullmore School Coonoor",
                                      "MSP Solai Nadar Memorial Higher Secondary school Dindigul",
                                      "National Higher Secondary School Mannargudi",
                                      "New Prince Matriculation Higher Secondary School Chennai",
                                      "PS Higher Secondary School Chennai",
                                      "Perks Matriculation Higher Secondary School Coimbatore",
                                      "Ponnu Matriculation Higher Secondary School Dharapuram",
                                      "R S Krishnan Higher Secondary School",
                                      "Railway Colony Municipal Higher Secondary School",
                                      "Railway Mixed Higher Secondary School Golden Rock Tiruchirappalli",
                                      "Rice City Matriculation Higher Secondary School",
                                      "Sacred Heart Matriculation School Kayyunni Gudalur",
                                      "Sainik School Amaravathinagar",
                                      "St Antonys Higher Secondary School Sholavandan",
                                      "St Antonys Higher Secondary School Thanjavur",
                                      "St Antonys Matriculation Higher Secondary School Srivilliputhur",
                                      "St Arul Anandar School Oriyur",
                                      "St Georges School Chennai",
                                      "St Josephs Boys School Coonoor",
                                      "St Joseph Boys Higher Secondary School Trichy",
                                      "St Josephs Matriculation Higher Secondary School Coimbatore",
                                      "St Josephs Higher Secondary School Ooty",
                                      "St Judes Public School & Junior College Kotagiri",
                                      "St Marys Anglo-Indian Higher Secondary School Chennai",
                                      "St Marys Higher Secondary School Dindigul",
                                      "St Mary’s Higher Secondary School Madurai",
                                      "St Marys Higher Secondary School Vickramasingapuram",
                                      "St Patricks Anglo Indian Higher Secondary School Chennai",
                                      "St Pauls Matriculation Higher Secondary School Neyveli",
                                      "St Xaviers Higher Secondary School Palayamkottai",
                                      "St Xaviers Higher Secondary School Thoothukudi",
                                      "SBOA School & Junior College Chennai",
                                      "Seth Bhaskar Matriculation Higher Secondary School Ambattur",
                                      "Sethupathi Higher Secondary School Madurai",
                                      "Sishya School Chennai",
                                      "SMB Matriculation School Dindigul",
                                      "SMSV Hr Sec School",
                                      "South Street Hindu Nadar Higher Secondary School",
                                      "Sri Raasi Vinayaga school",
                                      "Stanes Anglo Indian Higher Secondary School Coimbatore",
                                      "Stanes Anglo Indian Higher Secondary School Coonoor",
                                      "Sundravalli Memorial School",
                                      "Tansri Ubaidulla Matriculation Higher Secondary School Rajaghiri",
                                      "Thambu Higher Secondary School Coimbatore",
                                      "Town Higher Secondary School Kumbakonam",
                                      "Trinity Academy Namakkal",
                                      "Valliammal Matriculation Higher Secondary School",
                                      "Velankanni Matriculation And Higher Secondary School",
                                      "Vellayan Chettiyar Higher Secondary School",
                                      "Vivekananda Memorial Matriculation School Ooty",
                                      "Woodside School Ooty"],

Telangana: ["Abhyas School  Warangal",
                                      "Abhyasa Residential Public School Toopran Medak District",
                                      "Andhra Mahila Sabha School of Informatics Hyderabad",
                                      "Andhra Pradesh Residential School Sarvail Nalgonda",
                                      "APTWR School Eturnagaram",
                                      "Asafia School Hyderabad",
                                      "CHIREC International Hyderabad",
                                      "Dr S Hussain Zaheer Memorial High School",
                                      "Gitanjali Senior School Begumpet",
                                      "Goodmorning Grammar High School Karimnagar",
                                      "Gowtham Model School Hyderabad",
                                      "Green Gables International School Hyderabad",
                                      "Hyderabad Public School",
                                      "Indus International School-Hyderabad",
                                      "International School of Hyderabad",
                                      "Jovial High School Yacharam",
                                      "Kakatiya High School Nizamabad",
                                      "Krishi Public School Sathupalli",
                                      "Lakshanika International School",
                                      "Little Flower High School Hyderabad",
                                      "Loyola High School Karimnagar",
                                      "Nagarjuna High School Warangal",
                                      "Nasr School Hyderabad",
                                      "Open Minds  A Birla School near Gachibowli Hyderabad",
                                      "Panchavati High School Secunderabad",
                                      "Ravitheja Residential High School Nagarkurnool",
                                      "Silver Oaks  The School of Hyderabad Bachupally Hyderabad",
                                      "St Anns High School Secunderabad",
                                      "St Georges Grammar School",
                                      "St Johns Church High School Secunderabad",
                                      "St Patricks High School Secunderabad",
                                      "St Pauls High School Hyderabad",
                                      "St Thomas (SPG) Boys High School",
                                      "St Xaviers High School Suryapet",
                                      "Vidyaranya High School Saifabad",
                                      "Waldens Path Jubilee Hills"],
Tripura: ["Bhavans Tripura Vidya Mandir",
                                      "Hindi Higher Secondary School",
                                      "Holy Cross School Agartala",
                                      "Jawahar Navodaya Vidyalaya Dhalai Tripura",
                                      "Khowai Government Higher Secondary School",
                                      "Melaghar Class XII School",
                                      "Netaji Subhash Vidyaniketan",
                                      "St Pauls School Agartala",
                                      "Umakanta Academy"],
UttarPradesh: ["Amity International School",
                                      "Cathedral School of Lucknow",
                                      "Central Academy Senior Secondary School",
                                      "Central Modern School",
                                      "Childrens Academy Mall Avenue",
                                      "City Montessori School",
                                      "Colvin Taluqdars College",
                                      "CPL Public Inter College Nagram Gosainganj Lucknow",
                                      "La Martiniere College",
                                      "Loreto Convent",
                                      "Lucknow Public School multiple locations",
                                      "Modern School",
                                      "Mount Carmel School",
                                      "Rani Laxmi Bai Memorial Senior Secondary School",
                                      "St Fidelis College",
                                      "St Francis College",
                                      "St Pauls College",
                                      "Study Hall",
                                      "Vibgyor High International School",
                                      "Vidya Bharati Akhil Bharatiya Shiksha Sansthan"],
Uttrakhand: ["Aryaman Vikram Birla Institute of Learning Haldwani",
                                      "The Aryan School Dehradun",
                                      "The Asian School Dehradun",
                                      "Ashok Hall Girls Residential School Ranikhet",
                                      "Bhartiyam International School Rudrapur",
                                      "Birla Vidya Mandir Nainital",
                                      "Brightlands School Dehradun",
                                      "Campus School Pantnagar",
                                      "Confluence World School Rudrapur",
                                      "Convent of Jesus and Mary Waverley Mussoorie",
                                      "Delhi Public School Haldwani",
                                      "The Doon School Dehradun",
                                      "Ecole Globale International Girls School Dehradun",
                                      "G D Birla Memorial School Ranikhet",
                                      "Manava Bharati India International School two locations",
                                      "Maria Assumpta Convent School",
                                      "Monad Public School Gadarpur",
                                      "Montfort Senior Secondary School Roorkee",
                                      "Olympus High School Dehradun",
                                      "RAN Public School Rudrapur",
                                      "The Royal College Dehradun Dehradun",
                                      "St Georges College Mussoorie",
                                      "St Josephs Academy (Ranked 1st) Dehradun",
                                      "St Josephs College Nainital",
                                      "St Marys Convent High School Nainital",
                                      "Tulas International School Dehradun",
                                      "Unison World School Dehradun",
                                      "Woodstock School Mussoorie",
                                      "Wynberg Allen School Mussoorie"],
WestBengal: ["Asansol Arunoday High School",
                                      "Domohani Kelejora High School",
                                      "Loreto Convent Asansol",
                                      "St Patricks Higher Secondary School",
                                      "St Vincents High and Technical School",
                                      "Dr Grahams Homes Kalimpong",
                                      "Gandhi Ashram School",
                                      "Goethals Memorial School Kurseong",
                                      "Loreto Convent",
                                      "Mount Carmel School Darjeeling",
                                      "Mount Hermon School",
                                      "Rockvale Academy",
                                      "St Augustines School",
                                      "St Georges Higher Secondary School",
                                      "St Josephs School Darjeeling",
                                      "St Pauls School Darjeeling",
                                      "St Roberts School Darjeeling"],
Chandigarh: ["Bhavan Vidyalaya Chandigarh",
                                      "Chandigarh Baptist School",
                                      "Delhi Public School Chandigarh",
                                      "KB DAV Senior Secondary Public School",
                                      "Mount Carmel School",
                                      "St Annes Convent School Chandigarh",
                                      "St Johns High School",
                                      "St Joseph Senior Secondary School Chandigarh",
                                      "St Marys School Chandigarh",
                                      "St Stephens School Chandigarh",
                                      "Shivalik Public School Mohali",
                                      "St Xaviers Senior Secondary School",
                                      "Strawberry Fields World School",
                                      "Vatika High School for Deaf & Dumb",
                                      "Yadavindra Public School Mohali"],
Delhi: ["Adarsh Public School Vikaspuri",
                                      "Adarsh Shiksha Niketan School",
                                      "Ahlcon International School",
                                      "Air Force Bal Bharati School Lodhi Road",
                                      "Air Force Golden Jubilee Institute Subroto Park",
                                      "American Embassy School",
                                      "Amity International School",
                                      "Anglo Arabic Senior Secondary School Ajmeri Gate",
                                      "Apeejay Public School",
                                      "Army Public School Dhaula Kuan",
                                      "Army Public School Delhi Cantt",
                                      "Bal Bhavan International School Dwarka Sub City",
                                      "Bal Bharati Public School",
                                      "Balvantray Mehta Vidya Bhawan Anguridevi Shersingh",
                                      "Bharti Public School",
                                      "Bluebells School",
                                      "Carmel Convent School",
                                      "Convent of Jesus and Mary New Delhi",
                                      "DAV Public School Pushpanjali Enclave",
                                      "Darbari Lal DAV Model School",
                                      "Delhi Public School Dwarka",
                                      "Delhi Public School Rohini",
                                      "Delhi Public School Mathura Road",
                                      "Delhi Public School R K Puram",
                                      "Delhi Public School Vasant Kunj",
                                      "DTEA Senior Secondary School",
                                      "Delhi International School Dwarka",
                                      "Don Bosco School",
                                      "Doon Public School",
                                      "Faith Academy Delhi",
                                      "Father Agnel School New Delhi",
                                      "GBSSS No3 Palam Enclave",
                                      "GBSSSchool No1 Shakti Nagar",
                                      "G D Goenka Public School",
                                      "Greenfields Senior Secondary School",
                                      "Guru Harkishan Public School",
                                      "Guru Nanak Public School",
                                      "Gyan Bharati School Saket",
                                      "Holy Child Auxilium School Vasant Vihar",
                                      "Holy Cross School ",
                                      "Hope Hall Foundation School R K Puram",
                                      "The Indian Heights School Dwarka",
                                      "Kendriya Vidyalaya",
                                      "Kulachi Hansraj Model School",
                                      "Lady Irwin Senior Secondary School",
                                      "Laxman Public School",
                                      "Loreto Convent School Delhi",
                                      "Mater Dei School New Delhi",
                                      "Manav Sthali School",
                                      "Manava Bharati India International School",
                                      "Mann Public School",
                                      "Modern School ",
                                      "Montfort Senior Secondary School",
                                      "Mount Carmel School",
                                      "N C Jindal Public School",
                                      "Navy Children School Chanakyapuri",
                                      "New Era Public School Mayapuri",
                                      "Prabhu Dayal Public School",
                                      "Presentation Convent Senior Secondary School Delhi",
                                      "R D Rajpal public school",
                                      "Rajkiya Pratibha Vikas Vidyalaya Shalimar Bagh Delhi",
                                      "Raisina Bengali Senior Secondary School Gole Market New Delhi",
                                      "Rukmini Devi Public School Pitampura New Delhi",
                                      "Sahoday Senior Secondary School SDA Hauz Khas New Delhi",
                                      "Sanskriti School",
                                      "Sardar Patel Vidyalaya",
                                      "Springdales School",
                                      "Saint Giri Senior Secondary School",
                                      "St Columbas School",
                                      "St Francis De Sales School",
                                      "St Pauls School New Delhi",
                                      "St Johns Sr Sec School",
                                      "St Marks Senior Secondary Public School",
                                      "St Marks Senior Secondary School Janakpuri",
                                      "St Thomas School (New Delhi)",
                                      "St Xaviers School Delhi",
                                      "St Xaviers School Rohini",
                                      "Summer Fields School New Delhi",
                                      "Tagore International School New Delhi",
                                      "The Air Force School ",
                                      "The Mothers International School",
                                      "The Shri Ram School",
                                      "Vasant Valley School"],
Pudducherry: ["Bharath English High School",
                                      "Jawahar Navodaya Vidyalaya",
                                      "Lycee francais de Pondichéry",
                                      "Petit Seminaire Higher Secondary School",
                                      "St Marys Higher Secondary school"],
                                      Other: ["Other"]
                                  }
function makeSubmenu(value) {
if(value.length==0) document.getElementById("citySelect").innerHTML = "<option></option>";
else {
var citiesOptions = "";
for(cityId in citiesByState[value]) {
citiesOptions+="<option>"+citiesByState[value][cityId]+"</option>";
}
document.getElementById("citySelect").innerHTML = citiesOptions;
}
}
function displaySelected() { var country = document.getElementById("countrySelect").value;
var city = document.getElementById("citySelect").value;
alert(country+"\n"+city);
}
function resetSelection() {
document.getElementById("countrySelect").selectedIndex = 0;
document.getElementById("citySelect").selectedIndex = 0;
}
</script>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- Meta tag Keywords -->

    <!-- css files -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- Style-CSS -->
<link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Font-Awesome-Icons-CSS -->
    <!-- //css files -->

    <!-- web-fonts -->
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext"
     rel="stylesheet">
    <!-- //web-fonts -->
</head>

<body onload="resetSelection()">

<?php 
	require_once 'config.php';
			// initalize user class
			$user_obj = new Cl_User();
			
	if(!empty($_REQUEST['SignUp'])){
		try {
			  // print_r($_POST); die;
			   $data = $user_obj->SignUp($_POST);
			} catch (Exception $e) {
					$error = $e->getMessage();
				}
	}

?>

    <div class="main-bg">
        <!-- title -->

        <h2><a href="index.php"> <img src="images/logo3.png"  height="50px" width="170px" /></a>Enroll yourself for quiz competition IQ-2019 </h2>
        <!-- //title -->
        <div class="sub-main-w3">
            <div class="image-style">

            </div>
            <!-- vertical tabs -->
            <div class="vertical-tab">
                <div id="section1" class="section-w3ls">
                    <input type="radio" name="sections" id="option1" checked>
                    <label for="option1" class="icon-left-w3pvt"><span class="fa fa-user-circle" aria-hidden="true"></span>Sign In</label>
                    <article>
                        <form action="#" method="post">
                            <h3 class="legend">Sign In</h3>
                           
                            
                            <div class="input">
                                <span class="fa fa-user-o" aria-hidden="true"></span>
                                <input type="Username" placeholder="Username"  required />
                            </div>
                            <div class="input">
                                <span class="fa fa-key" aria-hidden="true"></span>
                                <input type="password" placeholder="Password" required />
                            </div>
                            <button type="submit" class="btn submit">Login</button><br/>
                            <div>
                            Create an account??   <a data-toggle="modal" href="#" data-target="#myModal" class="site-button m-b30 radius-xl m-lr5"> Sign Up</a>
                        </div>
                        </form>
                    </article>
                </div>
                <div id="section2" class="section-w3ls">
                    <input type="radio" name="sections" id="option2">
                    <label for="option2" class="icon-left-w3pvt"><span class="fa fa-briefcase" aria-hidden="true"></span>Payments</label>
                <article>
                        <form action="#" method="post">
                            <h3 class="legend" id="blin">Payments</h3>
                            
                        </form>
                </article>
                </div>
                <div id="section3" class="section-w3ls">
                    <input type="radio" name="sections" id="option3">
                    <label for="option3" class="icon-left-w3pvt"><span class="fa fa-trophy" aria-hidden="true"></span>Results</label>
                    <article>
                        <form action="#" method="post">
                            <h3 class="legend last">Results</h3>
                            <p class="para-style"></p>
                            <p class="para-style-2">First fill your Application Id.</p>
                           <div class="input">
                                <span class="fa fa-key" aria-hidden="true"></span>
                                <input type="password" placeholder="Application Id" required />
                            </div>
                            <div>
                              <div class="input">
                                <span class="" aria-hidden="true"></span>
                                <input type="password" placeholder="Status" required />
                            </div>
                            <div>
                            <button type="submit" class="btn submit last-btn">Submit</button>
                          </div>
                        </form>
                    </article>
                </div>
            </div>
            <!-- //vertical tabs -->
            <div class="clear"></div>
        </div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    X</button>
               <h4 class="modal-title" id="myModalLabel">
                    Enrollment Form </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8" >
                        
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Login" data-toggle="tab">Applicant Details</a></li>
                            <li><a href="#Registration" data-toggle="tab">Payment</a></li>
                        </ul>
                        
                        <div class="tab-content">
								<?php 
	require_once 'config.php';
			// initalize user class
			$user_obj = new Cl_User();
			
	if(!empty($_REQUEST)){
		try {
			  // print_r($_POST); die;
			   $data = $user_obj->SignUp($_POST);
			} catch (Exception $e) {
					$error = $e->getMessage();
				}
	}

?>				
                            <div class="tab-pane active" id="Login">
                                <form class="form-horizontal" method="post">
                                   <div class="form-group">
                                    <label for="name" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <input type="text"  class="form-control" name="name" id="email1" placeholder="Enter Full Name" 
                                         required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email"  class="form-control" id="email1" name="email" placeholder="Enter Email Address" 
                                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required/>
                                    </div>
                                </div>
                                 <div class="form-group">
                                <label class="control-label col-sm-2" for="pno">DOB:</label>
                                <div class="col-sm-10">          
                                  <input type="date"  class="form-control" id="dateofbirth" name="dob" placeholder="Enter DOB" required>
                                </div>
                              </div>
                            <div class="form-group">
                                    <label for="pno" class="col-sm-2 control-label">
                                        Phone </label>
                                    <div class="col-sm-10">
                                        <input type="number"  class="form-control" maxlength="10" name="phone" pattern="[0-9]+" placeholder="Enter Phone Number" required />
                                    </div>
                                </div>
                            <div class="form-group">
                                    <label for="addr" class="col-sm-2 control-label">
                                        Address</label>
                                    <div class="col-sm-10">
                                        <input type="addr"  class="form-control" name="address" id="email1" placeholder="Enter Address" required />
                                    </div>
                                </div>
                                <div class="form-group">
                            <label for="qual" class="col-sm-2 control-label">Qualification </label>
                            <div class="col-sm-10"> 
                                <select class="form-control" name="qualification" id="email1" >
                            <option>Select....</option>
                            <option>1-3</option>
                            <option>4-6</option>
                            <option>7-10</option>
                            <option>11-12</option>
                            </select>
                            </div>
                            </div>
                            <div class="form-group">
                                  <label for="state" class="col-sm-2 control-label">State</label>
                            <div class="col-sm-10"> 
                            <select id="countrySelect" size="1" name="state" onchange="makeSubmenu(this.value)">
<option value="" disabled selected>Choose State</option>
<option>AndhraPradesh</option>
      <option>ArunachalPradesh</option>
      <option>Assam</option>
      <option>Bihar</option>
      <option>Chhattisgarh</option>
 <option>Goa</option>
      <option>Haryana</option>
      <option>HimachalPradesh</option>
      <option>JammuandKashmir</option>
 <option>Jharkhand</option>
      <option>Karnataka</option>
      <option>Gujarat</option>
      <option>Kerala</option>
      <option>MadhyaPradesh</option>
 <option>Maharashtra</option>
      <option>Manipur</option>
      <option>Meghalaya</option>
      <option>Mizoram</option>
 <option>Nagaland</option>
      <option>Odisha</option>
      <option>Punjab</option>
      <option>Rajasthan</option>
 <option>Sikkim</option>
      <option>TamilNadu</option>
      <option>Telangana</option>
      <option>Tripura</option>
 <option>UttarPradesh</option>
      <option>Uttarakhand</option>
      <option>WestBengal</option>
 <option>Chandigarh</option>
      <option>Delhi</option>
      <option>Puducherry</option>
      <option>Other</option>
</select>
                                </select>
                              </div>
                            </div>
                            
                            <div class="form-group">
                                            <label class="control-label col-sm-2" for="qual">School</label>
                                      <div class="col-sm-10"> 
                                          <select id="citySelect" name="school" size="1" >
                                      <option value="" disabled selected>Choose School</option>
                                      <option></option>
                                      </select>
                                    </div>
                                    </div>
                                    <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Other School <i>if any</i></label>
                                    <div class="col-sm-10">
                                        <input type="text"  class="form-control" name="otherSchool" id="email1" placeholder="Enter School Nmae" 
                                        required/>
                                    </div>
                                </div>
                                    <div class="form-group">
                                              <label for="upload picture"  class="col-sm-2 control-label">Upload Photograph</label>
                                              <div class="col-sm-10">          
                                                <input type="file" name="ohotograph"/>
                                              </div>
                                    </div>
                                    <div class="form-group">
                                            <label class="control-label col-sm-2"  for="upload picture">Upload Aadhar Card:</label>
                                            <div class="col-sm-10">          
                                              <input type="file" name="aadharphoto"/>
                                            </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                    <button type="submit" name="SignUp" class="button1" >Submit</button>
                                    </div>
                                    </div>
                                    </form>
                                    </div>
                                    <div class="tab-pane" id="Registration">
                                    <form role="form" class="form-horizontal">
                                    <div class="display-td" >                            
                                    <img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png">
                                    </div>
                                    <br>
                                    <br>
                                    <div class="form-group">
                                    <label for="cno" class="col-sm-2 control-label">
                                        Card Number</label>
                                    <div class="col-sm-10">
                                        <input type="cno" class="form-control" id="cno" placeholder="Enter card number" />
                                    </div>
                                    </div>
                                    <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <select class="form-control">
                                                    <option>Mr.</option>
                                                    <option>Ms.</option>
                                                    <option>Mrs.</option>
                                                </select>
                                            </div>
                                            <div class="col-md-9">
                                                <input type="text" class="form-control" placeholder="Name" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="expdate" class="col-sm-2 control-label">
                                        Expiry Date</label>
                                    <div class="col-sm-10">
                                        <input type="expdate" class="form-control" id="expdate" placeholder="MM/YY" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="scd" class="col-sm-2 control-label">
                                      CV Code</label>
                                    <div class="col-sm-10">
                                        <input type="scd" class="form-control" id="scd" placeholder="***" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="button" class="button1 ">
                                            SUBSCRIBE</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
          <!--/.Panel 8-->
    
        <!-- copyright -->
    <h3 style="color:#fff;font-size: 14px;">.</h3>
        <!-- //copyright -->
    </div>


</body>
</html>