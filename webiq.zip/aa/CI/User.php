<?php
// session_start();
include('DBclass.php');

// 
/**
 * This User will have functions that hadles user registeration,
 * login and forget password functionality
 * @author muni
 * @copyright www.smarttutorials.net
 */
class Cl_User
{
	/**
	 * @var will going contain database connection
	 */
	protected $_con;
	
	/**
	 * it will initalize DBclass
	 */
	public function __construct()
	{
		$db = new Cl_DBclass();
		$this->_con = $db->con;
	}
	
	/**
	 * this will handles user ContactDetail process
	 * @param array $data
	 * @return boolean true or false based success 
	 */
	public function ContactDetail( array $data )
	{
		if( !empty( $data ) ){
		$name=$data['name'];
		$email=$data['email'];
		$contect=$data['contact'];
		$msg=$data['message'];
		
		$query = "INSERT INTO contactus (id , name,email ,contact ,message) VALUES (Null, '$name','$email','$contect','$msg')";
             echo '<script language="javascript">';
			 echo 'alert("successfully submitted Contact Information")';
			 echo '</script>';
			
			if(mysqli_query($this->_con, $query))
			    
			$last_id = mysqli_insert_id($this->_con);
		    
		      return true;
				} else{
				
			throw new Exception( USER_REGISTRATION_FAIL );
		}
		
		if(!empty($last_id)){
		$to_email = 'info@gmail.com';
		$subject = 'Contact Form Information';
		$message = 'Name:'.$name.'<br>Email:'.$email.'<br>phone'.$contect.'<br>Message'.$msg;
		$headers .= 'From: noreply @ company . com';
		$headers .= 'Cc: ratio.anil@gmail.com' . "\r\n";
		$send=mail($to_email,$subject,$message,$headers);
		
			if($send){
				$email = $email;
				$subject = 'subscribe';
				$message = 'thank for subscribe we will contact you shortly';
				$headers = 'From: noreply@company.com';
				
				mail($email,$subject,$message,$headers);
			}
		}
	}
	public function SignUp( array $data ){
		if(!empty($data)){
			$name=$data['name'];
			$email=$data['email'];
			$dob=$data['dob'];
			$phone=$data['phone'];
			$address=$data['address'];
			$qualification=$data['qualification'];
			$state=$data['state'];
			$school=$data['school'];
			$otherSchool=$data['otherSchool'];
			$imagename=$_FILES["pohotograph"]["name"]; 
			$imagename=$_FILES["aadharphoto"]["name"]; 

			//Get the content of the image and then add slashes to it 
			$pohotograph=addslashes (file_get_contents($_FILES['pohotograph']['tmp_name']));
			$aadharphoto=addslashes (file_get_contents($_FILES['aadharphoto']['tmp_name']));
			
			$password_string = '!@#$%*&abcdefghijklmnpqrstuwxyzABCDEFGHJKLMNPQRSTUWXYZ23456789';
            $password = substr(str_shuffle($password_string), 0, 12);
			
			$query = "INSERT INTO signup (id , name,password ,email , dob	 ,phone , address , state,qualification,school,photo,aadharcard) VALUES (Null, '$name', '$password','$email','$dob','$phone','$address','$state','$qualification','$school','$pohotograph','$aadharphoto')";
             echo '<script language="javascript">';
			 echo 'alert("User registration was successful")';
			 echo '</script>';
			
			if(mysqli_query($this->_con, $query))
			    
			$last_id = mysqli_insert_id($this->_con);
		    
		      return true;
				} else{
				
			throw new Exception( USER_REGISTRATION_FAIL );
		}
		
		if($last_id){
			
			$email = $email;
				$subject = 'User registration ';
				$message .= 'thank for registration ';
				$message .= 'your registration id  <strong>'.$last_id.'</strong><br> your password: '.$password;
				$headers = 'From: noreply@company.com';
				
				mail($email,$subject,$message,$headers);
			
		}

			
		}
}
	

	
	
