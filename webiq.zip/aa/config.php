<?php
require_once 'CI/User.php';
// require_once 'CI/messages.php';
//site specific configuration declartion
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define("DB_NAME", 'iqproject'); 
  
?>


